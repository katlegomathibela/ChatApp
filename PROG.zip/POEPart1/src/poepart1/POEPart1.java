package poepart1;

import javax.swing.JOptionPane;

public class POEPart1 {

    public static void main(String[] args) {
        ClassLogin use = new ClassLogin();

        JOptionPane.showMessageDialog(null, "***** USER REGISTRATION *****");

        String name = JOptionPane.showInputDialog("Enter your name:");
        use.setName(name);

        String surname = JOptionPane.showInputDialog("Enter your surname:");
        use.setSurname(surname);

        String phone_number = JOptionPane.showInputDialog("Enter your phone number (+27...)");
        use.setPhone_number(phone_number);
        if (use.checkPhoneNumber(phone_number)) {
            JOptionPane.showMessageDialog(null, "✅ Phone number successfully captured.");
        }
        while (!use.checkPhoneNumber(phone_number)) {
            JOptionPane.showMessageDialog(null, "❌ Phone number does not contain international code or is incorrectly formatted.");
            phone_number = JOptionPane.showInputDialog("Enter your phone number (+27...):");
            use.setPhone_number(phone_number);
        }
        JOptionPane.showMessageDialog(null, "✅ Phone number successfully captured.");

        String username = JOptionPane.showInputDialog("Enter your username (must contain underscore and be ≤ 5 characters):");
        use.setUserName(username);
        if (use.checkUserName(username)) {
            JOptionPane.showMessageDialog(null, "✅ Username successfully captured.");
        }
        while (!use.checkUserName(username)) {
            JOptionPane.showMessageDialog(null, "❌ Username is incorrectly formatted.\nEnsure it contains an underscore and is no more than 5 characters long.");
            username = JOptionPane.showInputDialog("Enter your username:");
            use.setUserName(username);
        }
        JOptionPane.showMessageDialog(null, "✅ Username successfully captured.");

        String password = JOptionPane.showInputDialog("Enter your password (min 8 characters, 1 capital, number & special character):");
        use.setPassword(password);
        if (use.checkPassword(password)) {
            JOptionPane.showMessageDialog(null, "✅ Password successfully captured.");
        }
        while (!use.checkPassword(password)) {
            JOptionPane.showMessageDialog(null, "❌ Password is incorrectly formatted.\nMust be 8+ characters with a capital letter, number, and special character.");
            password = JOptionPane.showInputDialog("Enter your password:");
            use.setPassword(password);
        }
        JOptionPane.showMessageDialog(null, "✅ Password successfully captured.");

        use.RegisterUser(password, username);

        JOptionPane.showMessageDialog(null, "***** USER LOGIN *****");

        String loginUsername = JOptionPane.showInputDialog("Username:");
        String loginPassword = JOptionPane.showInputDialog("Password:");

        while (!use.loginUser(loginPassword, loginUsername)) {
            JOptionPane.showMessageDialog(null, "❌ Username or Password incorrect. Please try again.");
            loginUsername = JOptionPane.showInputDialog("Username:");
            loginPassword = JOptionPane.showInputDialog("Password:");
        }

        use.returnLoginStatus(loginUsername, loginPassword);

        // Call menu or continue to next logic
        MessageManager.showMainMenu();
    }
}
